<?php
class Database
{
    //DB params

    private $host = 'lservice.01.lampt.eeecs.qub.ac.uk';
    private $db_name = 'lservice01';
    private $username = 'lservice01';
    private $password = 'rDr3GP2KVbLxmVxy';
    private $conn;

    //Connect method:
    public function connect() {
        $this->conn = null;

        /*We want to use this plus the arrow because it pertains to this quality or attribute - we want to connect a new pdo object and pass in the stuff we need.
*/

        try {
            // takes in database name, type and host for pdo...
            $this->conn = new PDO('mysql:host=' .  $this->host . ';dbname= ' . $this->db_name, $this->username, $this->password); // takes in database name, type, password etc to connect

            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Connection Error: ' . $e->getMessage();
        }

        //return connection
        return $this->conn;

    }
}

?>