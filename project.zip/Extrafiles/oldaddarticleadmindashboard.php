<!DOCTYPE html>
<html lang=en>

<head>
    <title> SoundTribe | Add Article </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="../csstylesheets/reviewstyling.css">


</head>

<body>

    <?php
include ('../modularcode/adminnav.php')
?>

        <div class="header text-center container-fluid" style="background-color: #fe3426;">
            <img id="readingdino" src="https://media.itsnicethat.com/images/5bab60217fa44c23540018bc.format-webp.width-2880_p3vrjC9nwKC8xMM7.webp" />
        </div>

        <div class="container">
            <h1>Admin Dash - Add an article...</h1>
            <hr>
        </div>

        <!doctype html>
        <html lang="en">



        <div class="container">

            <!-- This is really important to capture stuff for an admin  - to allow a web user to add data to a page - e.g. checkboxes, urls, names of products.
    The really important part is that the insert is blank data that you want to populate - the really important part is the NAME attribute which is the container which
    will store the data from the users' input. IT will push it to the server - it's extremely important!-->

            <!-- We want to post the data - the data goes through to the server - sent to a server process file 
            inside another serverside piece of code = sitting inside insertproduct.php we need to create this insert product firrst-->


            <form method="POST" action="insertproduct.php">
                <div class="form-group row">
                    <label class="col-4 col-form-label" for="AlbumImgUrl">Album Image URL:</label>
                    <div class="col-8">
                        <input name="AlbumImgUrl" type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-4 col-form-label" for="AlbumTitle">Album Title:</label>
                    <div class="col-8">
                        <input name="AlbumTitle" type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-4 col-form-label" for="ArtistName">Artist Name:</label>
                    <div class="col-8">
                        <input name="ArtistName" type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-4 col-form-label" for="LabelName">Record Label Name:</label>
                    <div class="col-8">
                        <input name="LabelName" type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="YearReleased" class="col-4 col-form-label">Year of album release:</label>
                    <div class="col-8">
                        <input name="YearReleased" placeholder="YYYY" type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="GenreID" class="col-4 col-form-label">Music Genre</label>
                    <div class="col-8">
                        <select name="GenreID" class="custom-select" required="required">
                    <option value="1">Electronic</option>
                    <option value="2">Metal</option>
                    <option value="3">Rock</option>
                    <option value="4 ">Rap</option>
                    <option value="5">Experimental</option>
                    <option value="6">Pop/R&B</option>
                    <option value="7 ">Folk/Country</option>
                    <option value="8">Jazz</option>
                    <option value="9">Global</option>
                </select>
                    </div>
                </div>

                <hr>

                <!-- NO TABLE FOR THIS.-->
                <div class="form-group row">
                    <label class="col-4 col-form-label" for="tagline">Album Tagline:</label>
                    <div class="col-8">
                        <textarea name="tagline" placeholder="Add 2-3 sentances to introduce the album." type="text" class="form-control" required="required"></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="ReviewContent" class="col-4 col-form-label">Review Text:</label>
                    <div class="col-8">
                        <!-- The text area gives you a large multiline textbox. Tags which belong in a form element is name. -->
                        <textarea name="ReviewContent" cols="60" rows="10" class="form-control" required="required"></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="Score" class="col-4 col-form-label">Score</label>
                    <div class="col-8">
                        <input name="Score" placeholder="Enter score between 1-100 (inclusive)" type="text" class="form-control" required="required">
                    </div>
                </div>



                <div class="form-group row">
                    <label for="BestNewMusicStatusID" class="col-4 col-form-label">Achieved best new music status? (80%+)</label>
                    <div class="col-8">
                        <select name="BestNewMusicStatusID" class="custom-select" required="required">
                    <option value="1">No</option>
                    <option value="2">Yes</option>
                </select>
                    </div>
                </div>

                <hr>

                <div class="form-group row">
                    <label class="col-4 col-form-label" for="Author">Author Name:</label>
                    <div class="col-8">
                        <input name="Author" placeholder="Your Name Here." type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="AuthorTypeID" class="col-4 col-form-label">Author Status:</label>
                    <div class="col-8">
                        <select name="AuthorTypeID" class="custom-select" required="required">
                            <option value="1">Contributor</option>
                            <option value="2">Associate Reviews Editor</option>
                            <option value="3">Tracks Co-ordinator</option>
                            <option value="4">Associate Staff Writer</option>
                            <option value="5 ">Contributing Editor</option>
                            <option value="6">Senior Staff Writer</option>
                            <option value="7">Assistant Editor</option>
                            <option value="8 ">Associate Editor</option>
                            <option value="9">Senior Editor</option>
                            <option value="10">Executive Editor</option>
                            <option value="11 ">Deputy News Editor</option>
                            <option value="12">Associate Features Editor</option>
                            <option value="13">Managing Editor</option>
                        </select>
                    </div>
                </div>



                <div class="form-group row">
                    <label for="DatePublished" class="col-4 col-form-label">Current Date:</label>
                    <div class="col-8">
                        <input name="DatePublished" placeholder="YYYY-MM-DD" type="text" class="form-control" required="required">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="DayPublishedID" class="col-4 col-form-label">Current Day:</label>
                    <div class="col-8">
                        <select name="DayPublishedID" class="custom-select" required="required">
                            <option value="0">Monday</option>
                            <option value="1">Tuesday</option>
                            <option value="2">Wednesday</option>
                            <option value="3">Thursday</option>
                            <option value="4 ">Friday</option>
                            <option value="5">Saturday</option>
                            <option value="6">Sunday</option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="YearPublished" class="col-4 col-form-label">Current Year:</label>
                    <div class="col-8">
                        <input name="YearPublished" placeholder="YYYY" type="text" class="form-control" required="required">
                    </div>
                </div>


                <div class="form-group row">
                    <div class="offset-4 col-8">
                        <!-- Submit data as POST to the server and submit to table - name belongs to buttons and text
                forms to capture data. -->
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>

        </div>


        <!-- JavaScript:-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js "></script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
        <script>
            $().button('toggle')
        </script>
</body>
</hmtl>