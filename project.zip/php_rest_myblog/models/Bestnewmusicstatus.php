<?php

class Post
{
    private $conn;
    //UPDATE TABLE
    private $table = 'SOUNDTRIBE_BestNewMusicStatus';

    //UPDATE VARS FROM COLUMNS
    public $BestNewMusicStatusID;
    public $BestNewMusicStatus;


    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read() // you can easily organise date of reviews through ORDER BY
    {
        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single()
    {
        //UPDATE OR REMOVE FUNCTION
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';

        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);

        //UPDATE ID
        $stmt->bindParam(1, $this->BestNewMusicStatusID);

        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //UPDATE
        $this->BestNewMusicStatus = $row['BestNewMusicStatus'];
    }

    public function create()
    {
        //UPDATE
        $query = 'INSERT INTO ' . $this->table . 'SET BestNewMusicStatus = :BestNewMusicStatus';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->BestNewMusicStatus = htmlspecialchars(strip_tags($this->BestNewMusicStatus));

        //UPDATE
        $stmt->bindParam(':BestNewMusicStatus', $this->BestNewMusicStatus);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function update()
    {
        //UPDATE
        $query = 'UPDATE ' . $this->table . 'SET BestNewMusicStatus = :BestNewMusicStatus
        WHERE BestNewMusicStatusID = :BestNewMusicStatusID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->BestNewMusicStatus = htmlspecialchars(strip_tags($this->BestNewMusicStatus));

        //UPDATE
        $stmt->bindParam(':BestNewMusicStatus', $this->BestNewMusicStatus);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function delete()
    {
        //UPDATE WHERE BestNewMusicStatusID
        $query = 'DELETE FROM  ' . $this->table . ' WHERE BestNewMusicStatusID = :BestNewMusicStatusID';

        $stmt = $this->conn->prepare($query);

        //UPDATE
        $this->BestNewMusicStatusID = htmlspecialchars(strip_tags($this->BestNewMusicStatusID));

        //UPDATE
        $stmt->bindParam(':BestNewMusicStatusID', $this->BestNewMusicStatusID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
