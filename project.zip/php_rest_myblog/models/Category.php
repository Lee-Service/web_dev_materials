<?php
class Category {
    //db stuff
    private $conn;
    private $table = 'categories';

    // properties
    public $id;
    public $name; 
    public $created_at;

    // constructor:
        public function __construct($db)
    { // the double underscore creates constructor
        $this->conn = $db;
    }

    // get categories
    public function read(){
        //create our query
        $query = 'SELECT id, name, created_at FROM ' . $this->table . ' ORDER BY created_at DESC';
    

    //prepare statement
    $stmt = $this->conn->prepare($query);

    // Execute query
    $stmt->execute();

    return $stmt;
}
}