<?php

class Post
{
    private $conn;
    //UPDATE TABLE
    private $table = 'SOUNDTRIBE_ReviewArticleData';

    //UPDATE VARS FROM COLUMNS
    public $ReviewDataID;
    public $ReviewAuthorID;
    public $DatePublished;
    public $DayPublishedID;
    public $YearPublished;
    public $ReviewContent;
    public $Score;
    public $BestNewMusicStatusID;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read() // you can easily organise date of reviews through ORDER BY
    {
        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single()
    {
        //UPDATE OR REMOVE FUNCTION
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';

        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);

        //UPDATE ID
        $stmt->bindParam(1, $this->ReviewDataID);

        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //UPDATE
        $this->ReviewAuthorID = $row['ReviewAuthorID'];
        $this->DatePublished = $row['DatePublished'];
        $this->DayPublishedID = $row['DayPublishedID'];
        $this->YearPublished = $row['YearPublished'];
        $this->AlbumDetailsID = $row['AlbumDetailsID'];
        $this->ReviewContent = $row['ReviewContent'];
        $this->Score = $row['Score'];
        $this->BestNewMusicStatusID = $row['BestNewMusicStatusID'];

    }

    public function create()
    {
        //UPDATE
        $query = 'INSERT INTO ' . $this->table . 'SET ReviewAuthorID = :ReviewAuthorID, DatePublished = :DatePublished, DayPublishedID = :DayPublishedID, YearPublished = :YearPublished, AlbumDetailsID = :AlbumDetailsID,ReviewContent = :ReviewContent, Score = :Score, BestNewMusicStatusID = :BestNewMusicStatusID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->ReviewAuthorID = htmlspecialchars(strip_tags($this->ReviewAuthorID));
        $this->DatePublished = htmlspecialchars(strip_tags($this->DatePublished));
        $this->DayPublishedID = htmlspecialchars(strip_tags($this->DayPublishedID));
        $this->YearPublished = htmlspecialchars(strip_tags($this->YearPublished));
        $this->AlbumDetailsID = htmlspecialchars(strip_tags($this->AlbumDetailsID));
        $this->ReviewContent = htmlspecialchars(strip_tags($this->ReviewContent));
        $this->Score = htmlspecialchars(strip_tags($this->Score));
        $this->BestNewMusicStatusID = htmlspecialchars(strip_tags($this->BestNewMusicStatusID));

        //UPDATE
        $stmt->bindParam(':ReviewAuthorID', $this->ReviewAuthorID);
        $stmt->bindParam(':DatePublished', $this->DatePublished);
        $stmt->bindParam(':DayPublishedID', $this->DayPublishedID);
        $stmt->bindParam(':YearPublished', $this->YearPublished);
        $stmt->bindParam(':AlbumDetailsID', $this->AlbumDetailsID);
        $stmt->bindParam(':ReviewContent', $this->ReviewContent);
        $stmt->bindParam(':Score', $this->Score);
        $stmt->bindParam(':BestNewMusicStatusID', $this->BestNewMusicStatusID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function update()
    {
        //UPDATE
        $query = 'UPDATE ' . $this->table . 'SET ReviewAuthorID = :ReviewAuthorID, DatePublished = :DatePublished, DayPublishedID = :DayPublishedID, YearPublished = :YearPublished, AlbumDetailsID = :AlbumDetailsID,ReviewContent = :ReviewContent, Score = :Score, BestNewMusicStatusID = :BestNewMusicStatusID
        WHERE ReviewDataID = :ReviewDataID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->ReviewAuthorID = htmlspecialchars(strip_tags($this->ReviewAuthorID));
        $this->DatePublished = htmlspecialchars(strip_tags($this->DatePublished));
        $this->DayPublishedID = htmlspecialchars(strip_tags($this->DayPublishedID));
        $this->YearPublished = htmlspecialchars(strip_tags($this->YearPublished));
        $this->AlbumDetailsID = htmlspecialchars(strip_tags($this->AlbumDetailsID));
        $this->ReviewContent = htmlspecialchars(strip_tags($this->ReviewContent));
        $this->Score = htmlspecialchars(strip_tags($this->Score));
        $this->BestNewMusicStatusID = htmlspecialchars(strip_tags($this->BestNewMusicStatusID));

        //UPDATE
        $stmt->bindParam(':ReviewAuthorID', $this->ReviewAuthorID);
        $stmt->bindParam(':DatePublished', $this->DatePublished);
        $stmt->bindParam(':DayPublishedID', $this->DayPublishedID);
        $stmt->bindParam(':YearPublished', $this->YearPublished);
        $stmt->bindParam(':AlbumDetailsID', $this->AlbumDetailsID);
        $stmt->bindParam(':ReviewContent', $this->ReviewContent);
        $stmt->bindParam(':Score', $this->Score);
        $stmt->bindParam(':BestNewMusicStatusID', $this->BestNewMusicStatusID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function delete()
    {
        //UPDATE WHERE ReviewDataID
        $query = 'DELETE FROM  ' . $this->table . ' WHERE ReviewDataID = :ReviewDataID';

        $stmt = $this->conn->prepare($query);

        //UPDATE
        $this->ReviewDataID = htmlspecialchars(strip_tags($this->ReviewDataID));

        //UPDATE
        $stmt->bindParam(':ReviewDataID', $this->ReviewDataID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
