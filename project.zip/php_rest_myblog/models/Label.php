<?php

class Post
{
    private $conn;
    //UPDATE TABLE
    private $table = 'SOUNDTRIBE_Label';

    //UPDATE VARS FROM COLUMNS
    public $LabelID;
    public $LabelName;


    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read() // you can easily organise date of reviews through ORDER BY
    {
        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single()
    {
        //UPDATE OR REMOVE FUNCTION
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';

        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);

        //UPDATE ID
        $stmt->bindParam(1, $this->LabelID);

        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //UPDATE
        $this->LabelName = $row['LabelName'];
    }

    public function create()
    {
        //UPDATE
        $query = 'INSERT INTO ' . $this->table . 'SET LabelName = :LabelName';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->LabelName = htmlspecialchars(strip_tags($this->LabelName));

        //UPDATE
        $stmt->bindParam(':LabelName', $this->LabelName);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function update()
    {
        //UPDATE
        $query = 'UPDATE ' . $this->table . 'SET LabelName = :LabelName
        WHERE LabelID = :LabelID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->LabelName = htmlspecialchars(strip_tags($this->LabelName));

        //UPDATE
        $stmt->bindParam(':LabelName', $this->LabelName);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function delete()
    {
        //UPDATE WHERE LabelID
        $query = 'DELETE FROM  ' . $this->table . ' WHERE LabelID = :LabelID';

        $stmt = $this->conn->prepare($query);

        //UPDATE
        $this->LabelID = htmlspecialchars(strip_tags($this->LabelID));

        //UPDATE
        $stmt->bindParam(':LabelID', $this->LabelID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
