<?php

class Post
{
    private $conn;
    //UPDATE TABLE
    private $table = 'SOUNDTRIBE_Genre';

    //UPDATE VARS FROM COLUMNS
    public $GenreID;
    public $Genre;


    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read() // you can easily organise date of reviews through ORDER BY
    {
        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single()
    {
        //UPDATE OR REMOVE FUNCTION
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';

        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);

        //UPDATE ID
        $stmt->bindParam(1, $this->GenreID);

        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //UPDATE
        $this->Genre = $row['Genre'];
    }

    public function create()
    {
        //UPDATE
        $query = 'INSERT INTO ' . $this->table . 'SET Genre = :Genre';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->Genre = htmlspecialchars(strip_tags($this->Genre));

        //UPDATE
        $stmt->bindParam(':Genre', $this->Genre);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function update()
    {
        //UPDATE
        $query = 'UPDATE ' . $this->table . 'SET Genre = :Genre
        WHERE GenreID = :GenreID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->Genre = htmlspecialchars(strip_tags($this->Genre));

        //UPDATE
        $stmt->bindParam(':Genre', $this->Genre);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function delete()
    {
        //UPDATE WHERE GenreID
        $query = 'DELETE FROM  ' . $this->table . ' WHERE GenreID = :GenreID';

        $stmt = $this->conn->prepare($query);

        //UPDATE
        $this->GenreID = htmlspecialchars(strip_tags($this->GenreID));

        //UPDATE
        $stmt->bindParam(':GenreID', $this->GenreID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
