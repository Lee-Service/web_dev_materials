<?php

class Post
{
    //DB stuff
    private $conn; //connection
    private $table = 'posts';

    //properties of POST - initialising here with all fields
    public $id;
    public $category_id;
    public $category_name;

    //we are going to use  a join to combine tables together and get category name of post

    public $title;
    public $body;
    public $author;
    public $created_at;

    //constructor with db - a constructor is a method which runs when you instantiate a class

    public function __construct($db)
    { // the double underscore creates constructor
        $this->conn = $db;
    }

    //get Posts or read posts

    public function read()
    {
        //create our query

        // Alias' with a join - it doesn't know what p or c is but we define this later - so we're going to define p as post and define c as categories and bring it in..
        // we want to get category name 
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';
        // this is where we define p and do a join to join the tables together

        // create prepare statement
        $stmt =  $this->conn->prepare($query);
        // prepare query statement but not execute yet... we can do this by below

        //execute;
        $stmt->execute();

        return $stmt;
    }

    // get single post
    public function read_single()
    {
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';
        // the question mark is because we're using PDO's bind param to bind something to this later - its a placeholder for now
        // LIMIT 0,1 = limit whats pulled back

        // prepare statement
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        // prepare statement
        $stmt =  $this->conn->prepare($query);

        //bind id - this is a positional param (?) in pdo you can add positional or named params - 
        $stmt->bindParam(1, $this->id);
        //we bind the id then execute the query

        $stmt->execute();

        // we want to fetch the array which will be returned (one record) then assign the properties

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //set properties
        $this->title = $row['title'];
        $this->body = $row['body'];
        $this->author = $row['author'];
        $this->category_id = $row['category_id'];
        $this->category_name = $row['category_name'];
    }

    //create post
    public function create()
    {
        // create our query - we use name params like :title to define these later
        $query = 'INSERT INTO ' . $this->table . 'SET title = :title, body = :body, author = :author, category_id = :category_id';

        // create prepare statement
        $stmt = $this->conn->prepare($query);

        //clean data - take data and wrap in some secure functions - we're running through to strip tags and stop special chars to sanitise data
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->title = htmlspecialchars(strip_tags($this->body));
        $this->title = htmlspecialchars(strip_tags($this->author));
        $this->title = htmlspecialchars(strip_tags($this->category_id));

        //bind the data - lets take care of the :body = binding named params
        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':body', $this->body);
        $stmt->bindParam(':author', $this->author);
        $stmt->bindParam(':category_id', $this->category_id);

        //Execute our query - we aren't returning, we're creating data
        if ($stmt->execute()) {
            return true;
        }

        // Print error if something goes wrong - %s = placeholder and \n new line 
        // this just means if something goes wrong with query we can see it in postman in the raw tab
        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    //Update post
    public function update()
    {
        // create our query - we use name params like :title to define these later
        $query = 'UPDATE ' . $this->table . 'SET title = :title, body = :body, author = :author, category_id = :category_id
         WHERE id = :id'; //where id = the named param

        // create prepare statement
        $stmt = $this->conn->prepare($query);

        //clean data - take data and wrap in some secure functions - we're running through to strip tags and stop special chars to sanitise data
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->title = htmlspecialchars(strip_tags($this->body));
        $this->title = htmlspecialchars(strip_tags($this->author));
        $this->title = htmlspecialchars(strip_tags($this->category_id));
        $this->id = htmlspecialchars(strip_tags($this->id));


        //bind the data - lets take care of the :body = binding named params
        $stmt->bindParam(':id', $this->title);
        $stmt->bindParam(':body', $this->body);
        $stmt->bindParam(':author', $this->author);
        $stmt->bindParam(':category_id', $this->category_id);
        $stmt->bindParam(':id', $this->id);


        //Execute our query - we aren't returning, we're updating data
        if ($stmt->execute()) {
            return true;
        }

        // Print error if something goes wrong - %s = placeholder and \n new line 
        // this just means if something goes wrong with query we can see it in postman in the raw tab
        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    //Delete Post
    public function delete()
    {
        // create query
        $query = 'DELETE FROM  ' . $this->table . ' WHERE id = :id';

        // create prepare statement
        $stmt = $this->conn->prepare($query);

        //Clean data - This is delete - so it only needs to take id 
        $this->id = htmlspecialchars(strip_tags($this->id));

        // bind the id data
        $stmt->bindParam(':id', $this->id);

        //Execute our query - we aren't returning, we're updating data
        if ($stmt->execute()) {
            return true;
        }

        // Print error if something goes wrong - %s = placeholder and \n new line 
        // this just means if something goes wrong with query we can see it in postman in the raw tab
        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
