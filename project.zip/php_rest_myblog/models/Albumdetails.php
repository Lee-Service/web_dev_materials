<?php

class Post
{
    private $conn;
    //UPDATE TABLE
    private $table = 'SOUNDTRIBE_AlbumDetails';

    //UPDATE VARS FROM COLUMNS
    public $AlbumDetailsID;
    public $AlbumTitle;
    public $AlbumArtist;
    public $YearReleased;
    public $AlbumLabel;
    public $AlbumGenre;
    public $AlbumImgUrl;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read() // you can easily organise date of reviews through ORDER BY
    {
        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single()
    {
        //UPDATE OR REMOVE FUNCTION
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';

        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);

        //UPDATE ID
        $stmt->bindParam(1, $this->AlbumDetailsID);

        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //UPDATE
        $this->AlbumTitle = $row['AlbumTitle'];
        $this->AlbumArtist = $row['AlbumArtist'];
        $this->YearReleased = $row['YearReleased'];
        $this->AlbumLabel = $row['AlbumLabel'];
        $this->AlbumGenre = $row['AlbumGenre'];
        $this->AlbumImgUrl = $row['AlbumImgUrl'];
    }

    public function create()
    {
        //UPDATE
        $query = 'INSERT INTO ' . $this->table . 'SET AlbumTitle = :AlbumTitle, AlbumArtist = :AlbumArtist, YearReleased = :YearReleased, AlbumLabel = :AlbumLabel, AlbumDetailsID = :AlbumDetailsID,AlbumGenre = :AlbumGenre, AlbumImgUrl = :AlbumImgUrl';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->AlbumTitle = htmlspecialchars(strip_tags($this->AlbumTitle));
        $this->AlbumArtist = htmlspecialchars(strip_tags($this->AlbumArtist));
        $this->YearReleased = htmlspecialchars(strip_tags($this->YearReleased));
        $this->AlbumLabel = htmlspecialchars(strip_tags($this->AlbumLabel));
        $this->AlbumDetailsID = htmlspecialchars(strip_tags($this->AlbumDetailsID));
        $this->AlbumGenre = htmlspecialchars(strip_tags($this->AlbumGenre));
        $this->AlbumImgUrl = htmlspecialchars(strip_tags($this->AlbumImgUrl));

        //UPDATE
        $stmt->bindParam(':AlbumTitle', $this->AlbumTitle);
        $stmt->bindParam(':AlbumArtist', $this->AlbumArtist);
        $stmt->bindParam(':YearReleased', $this->YearReleased);
        $stmt->bindParam(':AlbumLabel', $this->AlbumLabel);
        $stmt->bindParam(':AlbumDetailsID', $this->AlbumDetailsID);
        $stmt->bindParam(':AlbumGenre', $this->AlbumGenre);
        $stmt->bindParam(':AlbumImgUrl', $this->AlbumImgUrl);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function update()
    {
        //UPDATE
        $query = 'UPDATE ' . $this->table . 'SET AlbumTitle = :AlbumTitle, AlbumArtist = :AlbumArtist, YearReleased = :YearReleased, AlbumLabel = :AlbumLabel, AlbumDetailsID = :AlbumDetailsID,AlbumGenre = :AlbumGenre, AlbumImgUrl = :AlbumImgUrl
        WHERE AlbumDetailsID = :AlbumDetailsID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->AlbumTitle = htmlspecialchars(strip_tags($this->AlbumTitle));
        $this->AlbumArtist = htmlspecialchars(strip_tags($this->AlbumArtist));
        $this->YearReleased = htmlspecialchars(strip_tags($this->YearReleased));
        $this->AlbumLabel = htmlspecialchars(strip_tags($this->AlbumLabel));
        $this->AlbumDetailsID = htmlspecialchars(strip_tags($this->AlbumDetailsID));
        $this->AlbumGenre = htmlspecialchars(strip_tags($this->AlbumGenre));
        $this->AlbumImgUrl = htmlspecialchars(strip_tags($this->AlbumImgUrl));

        //UPDATE
        $stmt->bindParam(':AlbumTitle', $this->AlbumTitle);
        $stmt->bindParam(':AlbumArtist', $this->AlbumArtist);
        $stmt->bindParam(':YearReleased', $this->YearReleased);
        $stmt->bindParam(':AlbumLabel', $this->AlbumLabel);
        $stmt->bindParam(':AlbumDetailsID', $this->AlbumDetailsID);
        $stmt->bindParam(':AlbumGenre', $this->AlbumGenre);
        $stmt->bindParam(':AlbumImgUrl', $this->AlbumImgUrl);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function delete()
    {
        //UPDATE WHERE AlbumDetailsID
        $query = 'DELETE FROM  ' . $this->table . ' WHERE AlbumDetailsID = :AlbumDetailsID';

        $stmt = $this->conn->prepare($query);

        //UPDATE
        $this->AlbumDetailsID = htmlspecialchars(strip_tags($this->AlbumDetailsID));

        //UPDATE
        $stmt->bindParam(':AlbumDetailsID', $this->AlbumDetailsID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
