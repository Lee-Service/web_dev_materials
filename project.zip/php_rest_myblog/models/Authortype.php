<?php

class Post
{
    private $conn;
    //UPDATE TABLE
    private $table = 'SOUNDTRIBE_AuthorType';

    //UPDATE VARS FROM COLUMNS
    public $AuthorTypeID;
    public $AuthorType;


    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read() // you can easily organise date of reviews through ORDER BY
    {
        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single()
    {
        //UPDATE OR REMOVE FUNCTION
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id WHERE p.id = ? LIMIT 0,1';

        //UPDATE
        $query = 'SELECT c.name as category_name, p.id, p.category_id, p.title, p.body, p.author, p.created_at
        FROM ' . $this->table . ' p LEFT JOIN categories c on p.category_id = c.id ORDER BY p.created_at DESC';

        $stmt =  $this->conn->prepare($query);

        //UPDATE ID
        $stmt->bindParam(1, $this->AuthorTypeID);

        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        //UPDATE
        $this->AuthorType = $row['AuthorType'];
    }

    public function create()
    {
        //UPDATE
        $query = 'INSERT INTO ' . $this->table . 'SET AuthorType = :AuthorType';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->AuthorType = htmlspecialchars(strip_tags($this->AuthorType));

        //UPDATE
        $stmt->bindParam(':AuthorType', $this->AuthorType);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function update()
    {
        //UPDATE
        $query = 'UPDATE ' . $this->table . 'SET AuthorType = :AuthorType
        WHERE AuthorTypeID = :AuthorTypeID';

        $stmt = $this->conn->prepare($query);

        //UPDATE - CLEAN DATA
        $this->AuthorType = htmlspecialchars(strip_tags($this->AuthorType));

        //UPDATE
        $stmt->bindParam(':AuthorType', $this->AuthorType);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }

    public function delete()
    {
        //UPDATE WHERE AuthorTypeID
        $query = 'DELETE FROM  ' . $this->table . ' WHERE AuthorTypeID = :AuthorTypeID';

        $stmt = $this->conn->prepare($query);

        //UPDATE
        $this->AuthorTypeID = htmlspecialchars(strip_tags($this->AuthorTypeID));

        //UPDATE
        $stmt->bindParam(':AuthorTypeID', $this->AuthorTypeID);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s. \n", $stmt->error);
        return false;
    }
}
