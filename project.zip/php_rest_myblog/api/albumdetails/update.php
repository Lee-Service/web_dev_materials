<?php

header('Access-Control-Allow-Origin: *'); 
header('Content-Type: application/json');

header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

//UPDATE
include_once '../../../php_rest_myblog/config/Database.php';
include_once '../../../php_rest_myblog/models/AlbumDetails.php';


$database = new Database();
$db = $database->connect();

$post = new Post($db);

$data = json_decode(file_get_contents("php://input"));

//UPDATE
$post->AlbumDetailsID = $data->AlbumDetailsID;

//UPDATE
$post->AlbumDetailsID = $data->AlbumDetailsID;
$post->AlbumTitle = $data->AlbumTitle;
$post->AlbumArtist = $data->AlbumArtist;
$post->YearReleased = $data->YearReleased;
$post->AlbumLabel = $data->AlbumLabel;
$post->AlbumGenre = $data->AlbumGenre;
$post->AlbumImgUrl = $data->AlbumImgUrl;

//UPDATE
if($post->update()) {
    echo json_encode(
        array('message' => 'Album Updated'));
    } else {
    echo json_encode(
        array('message' => 'Album NOT Updated'));
    }  

