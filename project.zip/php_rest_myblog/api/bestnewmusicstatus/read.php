<?php

header('Access-Control-Allow-Origin: *'); 
header('Content-Type: application/json');

//UPDATE
include_once '../../../php_rest_myblog/config/Database.php';
include_once '../../../php_rest_myblog/models/Bestnewmusicstatus.php';


$database = new Database();
$db = $database->connect();

$post = new Post($db);

$result = $post->read();

$num = $result->rowCount();

if ($num > 0) {

    //UPDATE
    $BestNewMusicStatus_arr = array();
    //UPDATE
    $BestNewMusicStatus_arr['data'] = array();

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        //UPDATE
        $post_item = array(
            'BestNewMusicStatusID' => $BestNewMusicStatusID,
            'BestNewMusicStatus' => $BestNewMusicStatus
        );

            //UPDATE
        array_push($BestNewMusicStatus_arr['data'], $post_item); 
        }     
    
    //UPDATE
    echo json_encode($BestNewMusicStatus_arr);
    } else {
    echo json_encode(
        array('message' => 'No BestNewMusicStatus found')
    );
}
?>