<?php

//headers
header('Access-Control-Allow-Origin: *'); //we give everyone access, not limiting
header('Content-Type: application/json'); // accept jsons
 
include_once '../../php_rest_myblog/config/Database.php';
include_once '../../php_rest_myblog/models/Post.php';


// instantiate DB and connect
$database = new Database();
$db = $database->connect();

//instantiate our blog post object
$post = new Post($db);

//get id
// isset to check if something is set
//$get_superglobal is how we get from a param e.g. something .com ? gets the value of something.com?id=3
// the get id value gets the id and if set, set the id to id and then die (cut everything off)
$post->id = isset($_GET['id'])? $_GET['id'] : die();
// if the id is there it'll get put to post id

//call read single method in post model
//Get post
$post->read_single();

//we need to return json data so create array
$post_arr = array(
    'id' => $post->id,
    'title' => $post->title,
    'body' =>$post->body,
    'author' => $post->author,
    'category_id' => $post->category_id,
    'category_name' => $post->category_name
);

//Make a Json - we want to encode the array as a json
print_r(json_encode($post_arr));

//read a single object with all that data


