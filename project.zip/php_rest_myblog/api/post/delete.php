<?php

//headers
header('Access-Control-Allow-Origin: *'); //we give everyone access, not limiting
header('Content-Type: application/json'); // accept jsons

//heads on what we allow here
header('Access-Control-Allow-Methods: DELETE');

// what are we allowing here? We're allowing a comma separated list and we want content type and the allowed methods with authorisation and other stuff
// see from 18.30 in video 2 - php from scratch
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../php_rest_myblog/config/Database.php';
include_once '../../php_rest_myblog/models/Post.php';


// instantiate DB and connect
$database = new Database();
$db = $database->connect();

//instantiate our blog post object
$post = new Post($db);

// when we make request from postman we need to GET the data thats' POSTED.
// when we make request, we're going to add title, category id, etc - to get the raw posted data
// get contents and get whatever is submitted
$data = json_decode(file_get_contents("php://input"));

//AS ITS AN UPDATE WE NEED TO KNOW THE ID
$post->id = $data->id;


//Delete Post
if($post->delete()) {
    echo json_encode(
        array('message' => 'Post Deleted'));
    } else {
    echo json_encode(
        array('message' => 'Post NOT Deleted'));
    }

    // we can now paste the link of delete.php into post, set it as delete request and select the id using:
    // headers - content-type 
    // values - application/json
    // body - raw + :
    /*
    {
        "id": "7";
    }

    Then send it 
    You can use a get request using read.php to see if deleted
    Full crud API completed!
*/
    


    

