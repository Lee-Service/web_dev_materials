<?php

//headers
header('Access-Control-Allow-Origin: *'); //we give everyone access, not limiting
header('Content-Type: application/json'); // accept jsons

include_once '../../../php_rest_myblog/config/Database.php';
include_once '../../../php_rest_myblog/models/Post.php';

// instantiate DB and connect
$database = new Database();
$db = $database->connect();

//instantiate our blog post object
$post = new Post($db);

// we created the constructor it takes the db and adds to connection so we can use our query so we need to pass in db object

// blog post query - lets call read method
$result = $post->read();

// get row count
$num = $result->rowCount();

// check if there's any posts
if ($num > 0) {
    // initialise an array if there is any
    $posts_arr = array();

    // when we make a request, don't just return json array - we need to have a data value inside, incase we want to add pagination or version info
    $posts_arr['data'] = array();
    // this is where the posts data goes to - into this array - the result will give us the result from the read we've created so lets loop through
    // via a while loop

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        //extract something as a title
        extract($row);

        $post_item = array(
            'id' => $id,
            'title' => $title,
            'body' =>html_entity_decode($body), //lets wrap this in a function because a body of a blog should be html
            'author' => $author,
            'category_id' => $category_id,
            'category_name' => $category_name
        );

        // push to 'data'
        array_push($posts_arr['data'], $post_item); //loop through each item and push this to post
    }

    // turn to json - we want to turn the php array into json and output this
    echo json_encode($posts_arr);
} else {
    //no posts? Well, echo out json encode array with a mesage of nothing found
    echo json_encode(
        array('message' => 'No posts found')
    );
}

?>

