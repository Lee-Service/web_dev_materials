<?php

//headers
header('Access-Control-Allow-Origin: *'); //we give everyone access, not limiting
header('Content-Type: application/json'); // accept jsons

//heads on what we allow here
header('Access-Control-Allow-Methods: PUT');

// what are we allowing here? We're allowing a comma separated list and we want content type and the allowed methods with authorisation and other stuff
// see from 18.30 in video 2 - php from scratch
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../php_rest_myblog/config/Database.php';
include_once '../../php_rest_myblog/models/Post.php';


// instantiate DB and connect
$database = new Database();
$db = $database->connect();

//instantiate our blog post object
$post = new Post($db);

// when we make request from postman we need to GET the data thats' POSTED.
// when we make request, we're going to add title, category id, etc - to get the raw posted data
// get contents and get whatever is submitted
$data = json_decode(file_get_contents("php://input"));

//AS ITS AN UPDATE WE NEED TO KNOW THE ID
$post->id = $data->id;

// assign what we have in data to post object
$post->title = $data->title;
$post->body = $data->body;
$post->author = $data->author;
$post->category_id = $data->category_id;

//Update the post and encode json as arrays 
if($post->update()) {
    echo json_encode(
        array('message' => 'Post Updated'));
    } else {
    echo json_encode(
        array('message' => 'Post NOT Updated'));
    }

    // we can now paste the link of create.php into post and use a POST along with the following settings/code:
    // Body: raw 
    // Headers: Content-type 
    // value: application/json
    /*
    {
    "title": "My Tech Post",
    "body": "This is a sample post",
    "author": "Lee Service",
    "category_id": "1"
    }
*/
    


    

