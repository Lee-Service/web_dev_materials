<?php

header('Access-Control-Allow-Origin: *'); 
header('Content-Type: application/json');

header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

//UPDATE
include_once '../../../php_rest_myblog/config/Database.php';
include_once '../../../php_rest_myblog/models/ReviewArticleData.php';


$database = new Database();
$db = $database->connect();

$post = new Post($db);

$data = json_decode(file_get_contents("php://input"));

//UPDATE
$post->ReviewContentID = $data->ReviewContentID;

//UPDATE
$post->ReviewDataID = $data->ReviewDataID;
$post->ReviewAuthorID = $data->ReviewAuthorID;
$post->DatePublished = $data->DatePublished;
$post->DayPublished = $data->DayPublished;
$post->YearPublished = $data->YearPublished;
$post->ReviewContent = $data->ReviewContent;
$post->Score = $data->Score;
$post->BestNewMusicStatus = $data->BestNewMusicStatus;


//UPDATE
if($post->update()) {
    echo json_encode(
        array('message' => 'Article Updated'));
    } else {
    echo json_encode(
        array('message' => 'Article NOT Updated'));
    }  

