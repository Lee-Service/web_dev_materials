<?php

header('Access-Control-Allow-Origin: *'); 
header('Content-Type: application/json');

header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

//UPDATE
include_once '../../../php_rest_myblog/config/Database.php';
include_once '../../../php_rest_myblog/models/Daypublished.php';


$database = new Database();
$db = $database->connect();

$post = new Post($db);

$data = json_decode(file_get_contents("php://input"));

//UPDATE
$post->DayPublishedID = $data->DayPublishedID;

//UPDATE
$post->DayPublishedID = $data->DayPublishedID;
$post->DayPublished = $data->DayPublished;

//UPDATE
if($post->update()) {
    echo json_encode(
        array('message' => 'DayPublished Updated'));
    } else {
    echo json_encode(
        array('message' => 'DayPublished NOT Updated'));
    }  

