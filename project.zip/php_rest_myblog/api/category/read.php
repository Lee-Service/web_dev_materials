<?php

//headers
header('Access-Control-Allow-Origin: *'); //we give everyone access, not limiting
header('Content-Type: application/json'); // accept jsons

include_once '../../php_rest_myblog/config/Database.php';
include_once '../../php_rest_myblog/models/Category.php';


// instantiate DB and connect
$database = new Database();
$db = $database->connect();

//instantiate our category object
$category = new Category($db);

// we created the constructor it takes the db and adds to connection so we can use our query so we need to pass in db object

// Category Read query - lets call read method
$result = $category->read();

// get row count
$num = $result->rowCount();

// check if there's any categories
if ($num > 0) {
    // initialise a category array if there is any
    $cat_arr = array();

    // when we make a request, don't just return json array - we need to have a data value inside, incase we want to add pagination or version info
    $cat_arr['data'] = array();
    // this is where the posts data goes to - into this array - the result will give us the result from the read we've created so lets loop through
    // via a while loop

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        //extract something as a title
        extract($row);

        $cat_item = array(
            'id' => $id,
            'name' => $name
        );

        // push to 'data'
        array_push($cat_arr['data'], $cat_item); //loop through each item and push this to post
    }

    // turn to json - we want to turn the php array into json and output this
    echo json_encode($cat_arr);
} else {
    //no categories? Well, echo out json encode array with a mesage of nothing found
    echo json_encode(
        array('message' => 'No categories found')
    );
}

/* go to postman and add -> http://lservice01.lampt.eeecs.qub.ac.uk/php_rest_myblog/api/cateogry/read.php
GET Request
body = raw
value = application/json
headers = content-type
hit send to reutn json object with value key of data and array of categories with id in the name

?>
